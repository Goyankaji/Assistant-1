import { db } from "./db";
import { conversations, messages } from "@shared/schema";
import { desc, eq } from "drizzle-orm";

export interface IStorage {
  getConversation(id: number): Promise<typeof conversations.$inferSelect | undefined>;
  getConversations(): Promise<(typeof conversations.$inferSelect)[]>;
  createConversation(input: {
    title: string;
    problemType: string;
  }): Promise<typeof conversations.$inferSelect>;
  deleteConversation(id: number): Promise<void>;

  getMessages(conversationId: number): Promise<(typeof messages.$inferSelect)[]>;
  createMessage(input: {
    conversationId: number;
    role: string;
    content: string;
    imageBase64?: string | null;
  }): Promise<typeof messages.$inferSelect>;
}

export class DatabaseStorage implements IStorage {
  async getConversation(id: number) {
    const [row] = await db.select().from(conversations).where(eq(conversations.id, id));
    return row;
  }

  async getConversations() {
    return db.select().from(conversations).orderBy(desc(conversations.createdAt));
  }

  async createConversation(input: { title: string; problemType: string }) {
    const [row] = await db
      .insert(conversations)
      .values({ title: input.title, problemType: input.problemType })
      .returning();
    return row;
  }

  async deleteConversation(id: number) {
    await db.delete(messages).where(eq(messages.conversationId, id));
    await db.delete(conversations).where(eq(conversations.id, id));
  }

  async getMessages(conversationId: number) {
    return db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.createdAt);
  }

  async createMessage(input: {
    conversationId: number;
    role: string;
    content: string;
    imageBase64?: string | null;
  }) {
    const [row] = await db
      .insert(messages)
      .values({
        conversationId: input.conversationId,
        role: input.role,
        content: input.content,
        imageBase64: input.imageBase64 ?? null,
      })
      .returning();
    return row;
  }
}

export const storage = new DatabaseStorage();
