import type { Express } from "express";
import type { Server } from "http";
import { z } from "zod";
import OpenAI from "openai";
import { storage } from "./storage";
import { api } from "@shared/routes";
import {
  createVoiceMessageBodySchema,
  createImageMessageBodySchema,
  createTextMessageBodySchema,
  createConversationBodySchema,
  problemTypes,
} from "@shared/schema";
import { ensureCompatibleFormat, speechToText } from "./replit_integrations/audio/client";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

function sseSetup(res: any) {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
}

function sseSend(res: any, payload: unknown) {
  res.write(`data: ${JSON.stringify(payload)}\n\n`);
}

function tutorSystemPrompt(problemType: string) {
  return [
    "You are a friendly human-like tutor and doubt solver.",
    "Speak naturally like a real teacher.",
    "Ask one clarifying question if needed before solving.",
    "Explain step-by-step, but keep steps short.",
    "End with a quick check question to confirm understanding.",
    `Problem type: ${problemType}.`,
    "If an image is provided, interpret it carefully.",
  ].join(" ");
}

async function seedIfEmpty() {
  const existing = await storage.getConversations();
  if (existing.length > 0) return;
  const c1 = await storage.createConversation({
    title: "Quadratic equation help",
    problemType: "math",
  });
  await storage.createMessage({
    conversationId: c1.id,
    role: "assistant",
    content:
      "Tell me the exact equation (or upload a photo). Also, do you want factorization or formula method?",
  });

  const c2 = await storage.createConversation({
    title: "Kinematics word problem",
    problemType: "physics",
  });
  await storage.createMessage({
    conversationId: c2.id,
    role: "assistant",
    content:
      "Share the full question and what is given (speed/time/distance). I will guide you step-by-step.",
  });

  const c3 = await storage.createConversation({
    title: "Debug my loop",
    problemType: "coding",
  });
  await storage.createMessage({
    conversationId: c3.id,
    role: "assistant",
    content:
      "Paste the code and tell me what output you expect vs what you get. We'll fix it together.",
  });
}

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  await seedIfEmpty();

  app.get(api.meta.problemTypes.path, async (_req, res) => {
    res.json({ items: problemTypes });
  });

  app.get(api.conversations.list.path, async (_req, res) => {
    const conversations = await storage.getConversations();
    res.json(conversations);
  });

  app.get(api.conversations.get.path, async (req, res) => {
    const id = Number(req.params.id);
    const conversation = await storage.getConversation(id);
    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found" });
    }
    const msgs = await storage.getMessages(id);
    res.json({ ...conversation, messages: msgs });
  });

  app.post(api.conversations.create.path, async (req, res) => {
    try {
      const input = createConversationBodySchema.parse(req.body);
      const conversation = await storage.createConversation({
        title: input.title,
        problemType: input.problemType,
      });
      res.status(201).json(conversation);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0]?.message ?? "Invalid input",
          field: err.errors[0]?.path?.join("."),
        });
      }
      throw err;
    }
  });

  app.delete(api.conversations.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    const conversation = await storage.getConversation(id);
    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found" });
    }
    await storage.deleteConversation(id);
    res.status(204).send();
  });

  app.post(api.conversations.messages.sendText.path, async (req, res) => {
    const conversationId = Number(req.params.id);
    const conversation = await storage.getConversation(conversationId);
    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found" });
    }

    try {
      const input = createTextMessageBodySchema.parse(req.body);
      await storage.createMessage({
        conversationId,
        role: "user",
        content: input.content,
      });

      const history = await storage.getMessages(conversationId);
      const messagesForModel = [
        { role: "system" as const, content: tutorSystemPrompt(conversation.problemType) },
        ...history.map((m) => ({
          role: (m.role === "assistant" ? "assistant" : "user") as
            | "assistant"
            | "user",
          content: m.content,
        })),
      ];

      sseSetup(res);

      const stream = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: messagesForModel,
        stream: true,
        max_completion_tokens: 1200,
      });

      let full = "";
      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content || "";
        if (!delta) continue;
        full += delta;
        sseSend(res, { type: "transcript", data: delta });
      }

      await storage.createMessage({
        conversationId,
        role: "assistant",
        content: full,
      });

      sseSend(res, { type: "done", transcript: full });
      res.end();
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0]?.message ?? "Invalid input",
          field: err.errors[0]?.path?.join("."),
        });
      }
      if (res.headersSent) {
        sseSend(res, { type: "error", error: "Failed to send message" });
        return res.end();
      }
      throw err;
    }
  });

  app.post(api.conversations.messages.sendImage.path, async (req, res) => {
    const conversationId = Number(req.params.id);
    const conversation = await storage.getConversation(conversationId);
    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found" });
    }

    try {
      const input = createImageMessageBodySchema.parse(req.body);
      const userText = input.prompt?.trim()
        ? `Image question: ${input.prompt.trim()}`
        : "Please solve the problem shown in the image.";

      await storage.createMessage({
        conversationId,
        role: "user",
        content: userText,
        imageBase64: input.imageBase64,
      });

      sseSetup(res);

      const system = tutorSystemPrompt(conversation.problemType);
      const stream = await openai.chat.completions.create({
        model: "gpt-5.2",
        stream: true,
        max_completion_tokens: 1400,
        messages: [
          { role: "system", content: system },
          {
            role: "user",
            content: [
              { type: "text", text: userText },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${input.imageBase64}`,
                },
              },
            ],
          } as any,
        ],
      });

      let full = "";
      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content || "";
        if (!delta) continue;
        full += delta;
        sseSend(res, { type: "transcript", data: delta });
      }

      await storage.createMessage({
        conversationId,
        role: "assistant",
        content: full,
      });

      sseSend(res, { type: "done", transcript: full });
      res.end();
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0]?.message ?? "Invalid input",
          field: err.errors[0]?.path?.join("."),
        });
      }
      if (res.headersSent) {
        sseSend(res, { type: "error", error: "Failed to process image" });
        return res.end();
      }
      throw err;
    }
  });

  // Voice endpoint uses JSON body with base64 audio. Increase limit.
  app.post(api.conversations.messages.sendVoice.path, (req, res, next) => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const express = require("express");
    return express.json({ limit: "50mb" })(req, res, next);
  });

  app.post(api.conversations.messages.sendVoice.path, async (req, res) => {
    const conversationId = Number(req.params.id);
    const conversation = await storage.getConversation(conversationId);
    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found" });
    }

    try {
      const input = createVoiceMessageBodySchema.parse(req.body);
      const voice = input.voice ?? "alloy";

      const raw = Buffer.from(input.audio, "base64");
      const { buffer: audioBuffer, format } = await ensureCompatibleFormat(raw);

      const userTranscript = await speechToText(audioBuffer, format);
      await storage.createMessage({
        conversationId,
        role: "user",
        content: userTranscript,
      });

      const history = await storage.getMessages(conversationId);
      const messagesForModel = [
        { role: "system" as const, content: tutorSystemPrompt(conversation.problemType) },
        ...history.map((m) => ({
          role: (m.role === "assistant" ? "assistant" : "user") as
            | "assistant"
            | "user",
          content: m.content,
        })),
      ];

      sseSetup(res);
      sseSend(res, { type: "user_transcript", data: userTranscript });

      const stream = await openai.chat.completions.create({
        model: "gpt-audio",
        modalities: ["text", "audio"],
        audio: { voice, format: "pcm16" },
        messages: messagesForModel,
        stream: true,
      });

      let assistantTranscript = "";
      for await (const chunk of stream) {
        const delta = chunk.choices?.[0]?.delta as any;
        if (!delta) continue;

        if (delta?.audio?.transcript) {
          assistantTranscript += delta.audio.transcript;
          sseSend(res, { type: "transcript", data: delta.audio.transcript });
        }
        if (delta?.audio?.data) {
          sseSend(res, { type: "audio", data: delta.audio.data });
        }
      }

      await storage.createMessage({
        conversationId,
        role: "assistant",
        content: assistantTranscript,
      });

      sseSend(res, { type: "done", transcript: assistantTranscript });
      res.end();
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0]?.message ?? "Invalid input",
          field: err.errors[0]?.path?.join("."),
        });
      }
      if (res.headersSent) {
        sseSend(res, { type: "error", error: "Failed to process voice" });
        return res.end();
      }
      throw err;
    }
  });

  return httpServer;
}
