## Packages
(none needed)

## Notes
Voice recording uses MediaRecorder + provided client/replit_integrations/audio hooks; ensure audio-playback-worklet.js is served at /audio-playback-worklet.js (copy to client/public/ if needed).
SSE endpoints return text/event-stream; frontend parses `data: {json}` lines using @shared/routes sseEventSchema.
All fetch calls include credentials: "include".
Tailwind config already supports fontFamily via CSS vars; this UI uses CSS vars directly (no custom tailwind font utilities required).
