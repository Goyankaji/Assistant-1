import { Link } from "wouter";
import { BrainCircuit, Moon, Sun } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";

function getInitialTheme(): "light" | "dark" {
  const stored = localStorage.getItem("theme");
  if (stored === "dark" || stored === "light") return stored;
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export default function BrandHeader({
  rightSlot,
}: {
  rightSlot?: React.ReactNode;
}) {
  const [theme, setTheme] = useState<"light" | "dark">(getInitialTheme);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    localStorage.setItem("theme", theme);
  }, [theme]);

  const ToggleIcon = useMemo(() => (theme === "dark" ? Sun : Moon), [theme]);

  return (
    <div className="flex items-center justify-between gap-3 px-3 sm:px-4 py-3 border-b bg-card/40 backdrop-blur-xl">
      <div className="flex items-center gap-3 min-w-0">
        <Link
          href="/"
          className={cn(
            "group inline-flex items-center gap-2 rounded-2xl px-2 py-1.5",
            "hover:bg-muted/70 transition-colors"
          )}
          data-testid="nav-home"
        >
          <span
            className={cn(
              "grid place-items-center h-9 w-9 rounded-2xl",
              "bg-gradient-to-br from-primary/18 to-accent/20 border border-border shadow-[var(--shadow-sm)]",
              "group-hover:shadow-[var(--shadow)] transition-all duration-300"
            )}
          >
            <BrainCircuit className="h-5 w-5 text-primary" />
          </span>
          <span className="min-w-0">
            <div className="font-display text-base sm:text-lg leading-none">
              Doubt Solver
            </div>
            <div className="text-xs text-muted-foreground leading-tight">
              Human-like tutoring, voice & camera
            </div>
          </span>
        </Link>
      </div>

      <div className="flex items-center gap-2">
        {rightSlot}
        <button
          type="button"
          onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
          className={cn(
            "group relative inline-flex h-10 w-10 items-center justify-center rounded-2xl border bg-card/60 shadow-[var(--shadow-sm)]",
            "hover:shadow-[var(--shadow)] hover:-translate-y-0.5 active:translate-y-0",
            "transition-all duration-300"
          )}
          aria-label="Toggle theme"
          data-testid="theme-toggle"
        >
          <ToggleIcon className="h-4.5 w-4.5 text-foreground/80 group-hover:text-foreground transition-colors" />
          <span className="pointer-events-none absolute -inset-1 rounded-[1.2rem] ring-0 group-focus-visible:ring-4 ring-primary/15 transition" />
        </button>
      </div>
    </div>
  );
}
