import { useEffect, useMemo, useRef, useState } from "react";
import { GradientButton } from "@/components/GradientButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CameraCaptureDialog from "@/components/CameraCaptureDialog";
import { cn } from "@/lib/utils";
import { Camera, Mic, Send, Square, Wand2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useVoiceRecorder } from "../../replit_integrations/audio/useVoiceRecorder";

export default function ChatComposer({
  disabled,
  thinking,
  speaking,
  recording,
  onSendText,
  onSendImageBase64,
  onSendVoiceBase64,
  onStopAudio,
  problemTypeLabel,
}: {
  disabled?: boolean;
  thinking?: boolean;
  speaking?: boolean;
  recording?: boolean;
  onSendText: (text: string) => Promise<void>;
  onSendImageBase64: (imageBase64: string, prompt?: string) => Promise<void>;
  onSendVoiceBase64: (audioBase64: string) => Promise<void>;
  onStopAudio: () => void;
  problemTypeLabel?: string;
}) {
  const { toast } = useToast();
  const recorder = useVoiceRecorder();
  const [text, setText] = useState("");
  const [cameraOpen, setCameraOpen] = useState(false);
  const [imgPrompt, setImgPrompt] = useState("");

  const inputRef = useRef<HTMLInputElement | null>(null);

  const canSend = useMemo(() => text.trim().length > 0 && !disabled, [text, disabled]);

  useEffect(() => {
    if (!disabled) inputRef.current?.focus();
  }, [disabled]);

  const send = async () => {
    if (!canSend) return;
    const t = text.trim();
    setText("");
    try {
      await onSendText(t);
    } catch (e) {
      toast({
        title: "Message failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
      setText(t);
    }
  };

  const toggleRecord = async () => {
    try {
      if (recorder.state === "recording") {
        const blob = await recorder.stopRecording();
        const base64Audio = await new Promise<string>((resolve) => {
          const fr = new FileReader();
          fr.onload = () => {
            const s = String(fr.result);
            resolve(s.split(",")[1] || "");
          };
          fr.readAsDataURL(blob);
        });
        if (!base64Audio) throw new Error("No audio captured");
        await onSendVoiceBase64(base64Audio);
      } else {
        await recorder.startRecording();
      }
    } catch (e) {
      toast({
        title: "Voice failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  const onCaptured = async (imageBase64: string) => {
    try {
      await onSendImageBase64(imageBase64, imgPrompt.trim() || undefined);
      setImgPrompt("");
    } catch (e) {
      toast({
        title: "Image send failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  const showRecording = recording || recorder.state === "recording";

  return (
    <div className="border-t bg-card/40 backdrop-blur-xl p-3 sm:p-4">
      <div className="mx-auto max-w-3xl">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-2">
            <div className="text-xs text-muted-foreground">
              {problemTypeLabel ? (
                <span className="inline-flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-primary/80" />
                  Tutor mode: <span className="font-semibold capitalize text-foreground/85">{problemTypeLabel}</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-primary/80" />
                  Ask naturally — I’ll adapt like a tutor.
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs">
              {showRecording ? (
                <span
                  className="inline-flex items-center gap-2 rounded-full border bg-destructive/10 text-destructive px-3 py-1"
                  data-testid="status-recording"
                >
                  <span className="h-2 w-2 rounded-full bg-destructive animate-pulse" />
                  Recording…
                </span>
              ) : thinking ? (
                <span
                  className="inline-flex items-center gap-2 rounded-full border bg-primary/10 text-primary px-3 py-1"
                  data-testid="status-thinking"
                >
                  <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
                  Thinking…
                </span>
              ) : speaking ? (
                <span
                  className="inline-flex items-center gap-2 rounded-full border bg-accent/15 text-foreground px-3 py-1"
                  data-testid="status-speaking"
                >
                  <span className="h-2 w-2 rounded-full bg-accent animate-pulse" />
                  Speaking…
                </span>
              ) : (
                <span
                  className="inline-flex items-center gap-2 rounded-full border bg-muted/60 text-muted-foreground px-3 py-1"
                  data-testid="status-ready"
                >
                  Ready
                </span>
              )}
            </div>
          </div>

          <div className="rounded-3xl border bg-card/60 shadow-[var(--shadow)] p-2">
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <Input
                  ref={inputRef}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      send();
                    }
                  }}
                  placeholder="Explain your doubt… (press Enter to send)"
                  className={cn(
                    "h-12 rounded-2xl border-2 bg-background/40",
                    "focus-visible:ring-4 focus-visible:ring-primary/10 focus-visible:border-primary"
                  )}
                  disabled={!!disabled}
                  data-testid="composer-text"
                />
              </div>

              <GradientButton
                onClick={send}
                disabled={!canSend}
                icon={<Send className="h-4 w-4" />}
                className="h-12 px-4"
                data-testid="composer-send"
              >
                <span className="hidden sm:inline">Send</span>
              </GradientButton>
            </div>

            <div className="mt-2 flex flex-col sm:flex-row sm:items-center gap-2">
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="rounded-2xl"
                  onClick={() => setCameraOpen(true)}
                  disabled={!!disabled}
                  data-testid="composer-camera"
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Camera
                </Button>

                <Button
                  type="button"
                  variant={showRecording ? "destructive" : "outline"}
                  className={cn("rounded-2xl", showRecording && "shadow-[0_18px_45px_hsl(var(--destructive)/0.25)]")}
                  onClick={toggleRecord}
                  disabled={!!disabled}
                  data-testid="composer-mic"
                >
                  {showRecording ? <Square className="h-4 w-4 mr-2" /> : <Mic className="h-4 w-4 mr-2" />}
                  {showRecording ? "Stop" : "Voice"}
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  className="rounded-2xl"
                  onClick={onStopAudio}
                  disabled={!speaking}
                  data-testid="composer-stop-audio"
                >
                  <Square className="h-4 w-4 mr-2" />
                  Stop audio
                </Button>
              </div>

              <div className="sm:ml-auto flex-1 sm:flex-none">
                <div className="relative">
                  <Wand2 className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={imgPrompt}
                    onChange={(e) => setImgPrompt(e.target.value)}
                    placeholder="Optional: what should I focus on in your image?"
                    className="pl-9 h-11 rounded-2xl bg-background/40"
                    disabled={!!disabled}
                    data-testid="composer-image-prompt"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-muted-foreground">
            Tip: If you’re stuck, share what you tried. I’ll guide you with questions, not just answers.
          </div>
        </div>
      </div>

      <CameraCaptureDialog open={cameraOpen} onOpenChange={setCameraOpen} onCaptured={onCaptured} />
    </div>
  );
}
