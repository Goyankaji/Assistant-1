import { PropsWithChildren } from "react";
import { cn } from "@/lib/utils";

export default function AppShell({
  children,
  className,
}: PropsWithChildren<{ className?: string }>) {
  return (
    <div className={cn("min-h-dvh bg-background text-foreground mesh-bg", className)}>
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute inset-0 opacity-90 dark:opacity-100" />
      </div>

      <div className="relative mx-auto max-w-7xl px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
        <div className="relative overflow-hidden rounded-3xl border bg-card/60 shadow-[var(--shadow-lg)] backdrop-blur-xl">
          <div className="relative grain">{children}</div>
        </div>
      </div>
    </div>
  );
}
