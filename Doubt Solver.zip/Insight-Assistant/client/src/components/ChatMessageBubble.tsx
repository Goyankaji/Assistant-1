import { cn } from "@/lib/utils";
import { Bot, User } from "lucide-react";

export default function ChatMessageBubble({
  role,
  content,
  imageBase64,
  createdAtLabel,
}: {
  role: string;
  content: string;
  imageBase64?: string | null;
  createdAtLabel?: string;
}) {
  const isUser = role === "user";
  return (
    <div
      className={cn(
        "flex gap-3 sm:gap-4",
        isUser ? "justify-end" : "justify-start"
      )}
      data-testid={`chat-bubble-${isUser ? "user" : "assistant"}`}
    >
      {!isUser ? (
        <div className="hidden sm:flex h-10 w-10 shrink-0 rounded-2xl border bg-gradient-to-br from-primary/15 to-accent/15 items-center justify-center shadow-[var(--shadow-sm)]">
          <Bot className="h-5 w-5 text-primary" />
        </div>
      ) : null}

      <div className={cn("max-w-[92%] sm:max-w-[78%]")}>
        <div
          className={cn(
            "rounded-3xl border px-4 py-3 shadow-[var(--shadow-sm)]",
            "transition-all duration-300",
            isUser
              ? "bg-gradient-to-br from-primary to-primary/80 text-primary-foreground border-primary/35"
              : "bg-card/70 text-card-foreground border-card-border"
          )}
        >
          {imageBase64 ? (
            <div className="mb-3 overflow-hidden rounded-2xl border bg-background/40">
              <img
                src={`data:image/jpeg;base64,${imageBase64}`}
                alt="Uploaded problem"
                className="w-full h-auto max-h-[360px] object-contain"
                data-testid="chat-image"
              />
            </div>
          ) : null}

          <div className={cn("whitespace-pre-wrap text-sm sm:text-[15px] leading-relaxed")}>
            {content}
          </div>
        </div>

        {createdAtLabel ? (
          <div
            className={cn(
              "mt-1 text-[11px] text-muted-foreground",
              isUser ? "text-right" : "text-left"
            )}
            data-testid="chat-timestamp"
          >
            {createdAtLabel}
          </div>
        ) : null}
      </div>

      {isUser ? (
        <div className="hidden sm:flex h-10 w-10 shrink-0 rounded-2xl border bg-card/70 items-center justify-center shadow-[var(--shadow-sm)]">
          <User className="h-5 w-5 text-foreground/80" />
        </div>
      ) : null}
    </div>
  );
}
