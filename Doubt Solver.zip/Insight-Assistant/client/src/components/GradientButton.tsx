import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";
import * as React from "react";

export function GradientButton({
  className,
  loading,
  icon,
  children,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  loading?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <button
      {...props}
      className={cn(
        "group relative inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold",
        "bg-gradient-to-r from-primary to-primary/85 text-primary-foreground shadow-[0_18px_45px_hsl(var(--primary)/0.28)]",
        "hover:shadow-[0_24px_70px_hsl(var(--primary)/0.34)] hover:-translate-y-0.5 active:translate-y-0",
        "disabled:opacity-55 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none",
        "transition-all duration-300",
        className
      )}
    >
      <span className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-[radial-gradient(900px_circle_at_20%_20%,hsl(var(--accent)/0.25),transparent_50%)]" />
      <span className="relative inline-flex items-center gap-2">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : icon}
        {children}
      </span>
    </button>
  );
}
