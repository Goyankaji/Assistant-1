import { useMemo, useState } from "react";
import { useProblemTypes } from "@/hooks/use-meta";
import { useCreateConversation } from "@/hooks/use-conversations";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { GradientButton } from "@/components/GradientButton";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import type { ProblemType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function ConversationCreateDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated?: (id: number) => void;
}) {
  const { toast } = useToast();
  const { data } = useProblemTypes();
  const create = useCreateConversation();

  const options = data?.items ?? [];
  const defaultType = (options[0] ?? "math") as ProblemType;

  const [title, setTitle] = useState("");
  const [problemType, setProblemType] = useState<ProblemType>(defaultType);

  const canSubmit = useMemo(() => {
    return title.trim().length > 0 && !!problemType && !create.isPending;
  }, [title, problemType, create.isPending]);

  const submit = async () => {
    try {
      const res = await create.mutateAsync({ title: title.trim(), problemType });
      toast({ title: "New doubt created", description: "Let’s solve it step-by-step." });
      setTitle("");
      onOpenChange(false);
      onCreated?.(res.id);
    } catch (e) {
      toast({
        title: "Couldn’t create conversation",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl p-0 overflow-hidden max-w-lg">
        <div className="p-5 sm:p-6 bg-[radial-gradient(900px_circle_at_20%_0%,hsl(var(--primary)/0.18),transparent_55%),radial-gradient(900px_circle_at_90%_40%,hsl(var(--accent)/0.16),transparent_60%)]">
          <DialogHeader>
            <DialogTitle className="text-2xl">Start a new doubt</DialogTitle>
          </DialogHeader>

          <div className="mt-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., ‘Explain this integral’ or ‘Fix my Python error’"
                className="rounded-2xl h-12"
                data-testid="newdoubt-title"
              />
              <p className="text-xs text-muted-foreground">
                Tip: Keep it human. Your tutor adapts tone + pace.
              </p>
            </div>

            <div className="space-y-2">
              <Label>Problem type</Label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {options.map((t) => {
                  const active = t === problemType;
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setProblemType(t as ProblemType)}
                      className={[
                        "rounded-2xl border px-3 py-2 text-sm font-semibold capitalize text-left",
                        "transition-all duration-300 hover:-translate-y-0.5",
                        active
                          ? "bg-primary text-primary-foreground border-primary/40 shadow-[0_16px_40px_hsl(var(--primary)/0.22)]"
                          : "bg-card/70 hover:bg-muted/70 shadow-[var(--shadow-sm)]",
                      ].join(" ")}
                      data-testid={`problemtype-${t}`}
                    >
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 pt-2">
              <Button
                variant="outline"
                className="rounded-2xl"
                onClick={() => onOpenChange(false)}
                data-testid="newdoubt-cancel"
              >
                Cancel
              </Button>
              <GradientButton
                onClick={submit}
                disabled={!canSubmit}
                loading={create.isPending}
                icon={<Sparkles className="h-4 w-4" />}
                data-testid="newdoubt-create"
              >
                Create
              </GradientButton>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
