import { cn } from "@/lib/utils";
import { PropsWithChildren } from "react";

export function SoftCard({
  className,
  children,
}: PropsWithChildren<{ className?: string }>) {
  return (
    <div
      className={cn(
        "rounded-3xl border bg-card/70 shadow-[var(--shadow)] backdrop-blur-xl",
        "hover:shadow-[var(--shadow-lg)] transition-all duration-300",
        className
      )}
    >
      {children}
    </div>
  );
}
