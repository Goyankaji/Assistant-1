
const types = ["OS", "SE", "DBMS", "DSA"];

export default function ProblemTypeFilter({ onSelect }: { onSelect: (t: string) => void }) {
  return (
    <div className="flex gap-3 mb-6">
      {types.map(t => (
        <button
          key={t}
          onClick={() => onSelect(t)}
          className="px-4 py-2 rounded-xl bg-gray-100 hover:bg-black hover:text-white transition"
        >
          {t}
        </button>
      ))}
    </div>
  );
}
