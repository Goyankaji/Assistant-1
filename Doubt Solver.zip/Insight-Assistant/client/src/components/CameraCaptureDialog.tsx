import { useEffect, useMemo, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { GradientButton } from "@/components/GradientButton";
import { Button } from "@/components/ui/button";
import { Camera, Image as ImageIcon, RefreshCcw, Upload, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

function dataUrlToBase64(dataUrl: string): string {
  const idx = dataUrl.indexOf(",");
  return idx >= 0 ? dataUrl.slice(idx + 1) : dataUrl;
}

export default function CameraCaptureDialog({
  open,
  onOpenChange,
  onCaptured,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCaptured: (imageBase64: string) => void;
}) {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [mode, setMode] = useState<"camera" | "upload">("camera");
  const [preview, setPreview] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);

  const stopStream = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  };

  const startCamera = async () => {
    setStarting(true);
    try {
      stopStream();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (e) {
      toast({
        title: "Camera unavailable",
        description: "Please use upload instead (or grant permission).",
        variant: "destructive",
      });
      setMode("upload");
    } finally {
      setStarting(false);
    }
  };

  useEffect(() => {
    if (!open) {
      stopStream();
      setPreview(null);
      return;
    }
    if (mode === "camera") startCamera();
    return () => stopStream();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, mode]);

  const capture = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const w = video.videoWidth || 1280;
    const h = video.videoHeight || 720;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, w, h);
    const url = canvas.toDataURL("image/jpeg", 0.9);
    setPreview(url);
  };

  const useImage = () => {
    if (!preview) return;
    onCaptured(dataUrlToBase64(preview));
    onOpenChange(false);
    setPreview(null);
  };

  const upload = async (file: File) => {
    const reader = new FileReader();
    const dataUrl = await new Promise<string>((resolve, reject) => {
      reader.onerror = () => reject(new Error("Failed to read file"));
      reader.onload = () => resolve(String(reader.result));
      reader.readAsDataURL(file);
    });
    setPreview(dataUrl);
  };

  const title = useMemo(() => (mode === "camera" ? "Camera capture" : "Upload image"), [mode]);

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? onOpenChange(true) : onOpenChange(false))}>
      <DialogContent className="rounded-3xl p-0 overflow-hidden max-w-2xl">
        <div className="p-5 sm:p-6 bg-[radial-gradient(900px_circle_at_20%_0%,hsl(var(--primary)/0.18),transparent_55%),radial-gradient(900px_circle_at_90%_40%,hsl(var(--accent)/0.16),transparent_60%)]">
          <DialogHeader>
            <DialogTitle className="text-2xl">{title}</DialogTitle>
          </DialogHeader>

          <div className="mt-4 grid grid-cols-1 lg:grid-cols-5 gap-4">
            <div className="lg:col-span-3">
              <div className={cn("relative overflow-hidden rounded-3xl border bg-card/60 shadow-[var(--shadow)]")}>
                {preview ? (
                  <img
                    src={preview}
                    alt="Captured preview"
                    className="w-full h-[320px] sm:h-[420px] object-contain bg-background/40"
                    data-testid="camera-preview"
                  />
                ) : mode === "camera" ? (
                  <video
                    ref={videoRef}
                    playsInline
                    muted
                    className="w-full h-[320px] sm:h-[420px] object-cover bg-background/40"
                    data-testid="camera-video"
                  />
                ) : (
                  <div className="h-[320px] sm:h-[420px] grid place-items-center text-center p-8">
                    <div>
                      <div className="mx-auto h-12 w-12 rounded-2xl border bg-gradient-to-br from-primary/15 to-accent/15 grid place-items-center">
                        <ImageIcon className="h-6 w-6 text-primary" />
                      </div>
                      <div className="mt-3 font-semibold">Drop an image of your problem</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Screenshot, textbook, handwriting — anything works.
                      </div>
                    </div>
                  </div>
                )}

                {starting ? (
                  <div className="absolute inset-0 grid place-items-center bg-background/40 backdrop-blur-sm">
                    <div className="rounded-2xl border bg-card/70 px-4 py-2 shadow-[var(--shadow-sm)] text-sm">
                      Starting camera…
                    </div>
                  </div>
                ) : null}
              </div>

              <canvas ref={canvasRef} className="hidden" />
            </div>

            <div className="lg:col-span-2 space-y-3">
              <div className="rounded-3xl border bg-card/60 p-4 shadow-[var(--shadow-sm)]">
                <div className="text-sm font-semibold">Mode</div>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setMode("camera")}
                    className={cn(
                      "rounded-2xl border px-3 py-2 text-sm font-semibold transition-all duration-300",
                      mode === "camera"
                        ? "bg-primary text-primary-foreground border-primary/40 shadow-[0_16px_40px_hsl(var(--primary)/0.22)]"
                        : "bg-card/70 hover:bg-muted/70"
                    )}
                    data-testid="camera-mode-camera"
                  >
                    <span className="inline-flex items-center gap-2">
                      <Camera className="h-4 w-4" /> Camera
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode("upload")}
                    className={cn(
                      "rounded-2xl border px-3 py-2 text-sm font-semibold transition-all duration-300",
                      mode === "upload"
                        ? "bg-primary text-primary-foreground border-primary/40 shadow-[0_16px_40px_hsl(var(--primary)/0.22)]"
                        : "bg-card/70 hover:bg-muted/70"
                    )}
                    data-testid="camera-mode-upload"
                  >
                    <span className="inline-flex items-center gap-2">
                      <Upload className="h-4 w-4" /> Upload
                    </span>
                  </button>
                </div>

                {mode === "upload" ? (
                  <div className="mt-3">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) upload(f);
                      }}
                      className="block w-full text-sm file:mr-3 file:rounded-xl file:border file:bg-card/70 file:px-3 file:py-2 file:text-sm file:font-semibold hover:file:bg-muted/70"
                      data-testid="camera-upload-input"
                    />
                  </div>
                ) : null}
              </div>

              <div className="rounded-3xl border bg-card/60 p-4 shadow-[var(--shadow-sm)]">
                <div className="text-sm font-semibold">Actions</div>

                <div className="mt-3 space-y-2">
                  {mode === "camera" ? (
                    <>
                      <GradientButton
                        onClick={capture}
                        className="w-full"
                        icon={<Camera className="h-4 w-4" />}
                        disabled={starting}
                        data-testid="camera-capture"
                      >
                        Capture
                      </GradientButton>
                      <Button
                        variant="outline"
                        className="w-full rounded-2xl"
                        onClick={startCamera}
                        disabled={starting}
                        data-testid="camera-restart"
                      >
                        <RefreshCcw className="h-4 w-4 mr-2" />
                        Restart camera
                      </Button>
                    </>
                  ) : null}

                  <Button
                    variant="outline"
                    className="w-full rounded-2xl"
                    onClick={() => setPreview(null)}
                    disabled={!preview}
                    data-testid="camera-clear"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Clear preview
                  </Button>

                  <GradientButton
                    onClick={useImage}
                    className="w-full"
                    icon={<ImageIcon className="h-4 w-4" />}
                    disabled={!preview}
                    data-testid="camera-use"
                  >
                    Use this image
                  </GradientButton>

                  <Button
                    variant="ghost"
                    className="w-full rounded-2xl"
                    onClick={() => onOpenChange(false)}
                    data-testid="camera-close"
                  >
                    Close
                  </Button>
                </div>

                <div className="mt-3 text-xs text-muted-foreground">
                  Your tutor will read the image and ask clarifying questions when needed.
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
