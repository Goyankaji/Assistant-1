import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { useConversations, useDeleteConversation } from "@/hooks/use-conversations";
import { Input } from "@/components/ui/input";
import { GradientButton } from "@/components/GradientButton";
import ConversationCreateDialog from "@/components/ConversationCreateDialog";
import ConfirmDialog from "@/components/ConfirmDialog";
import { cn } from "@/lib/utils";
import { Calendar, MessageSquareText, Plus, Search, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

function asDate(d: unknown): Date {
  if (d instanceof Date) return d;
  if (typeof d === "string") return new Date(d);
  return new Date();
}

export default function ConversationSidebar() {
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const list = useConversations({ limit: 50 });
  const del = useDeleteConversation();

  const [createOpen, setCreateOpen] = useState(false);
  const [q, setQ] = useState("");
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const items = list.data ?? [];
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return items;
    return items.filter((c) => (c.title ?? "").toLowerCase().includes(s) || (c.problemType ?? "").toLowerCase().includes(s));
  }, [items, q]);

  const activeId = useMemo(() => {
    const m = location.match(/\/c\/(\d+)/);
    return m ? Number(m[1]) : null;
  }, [location]);

  const onDelete = async (id: number) => {
    try {
      await del.mutateAsync(id);
      toast({ title: "Conversation deleted", description: "That thread is gone." });
      if (activeId === id) setLocation("/");
    } catch (e) {
      toast({
        title: "Delete failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setConfirmId(null);
    }
  };

  return (
    <aside className="h-[calc(100dvh-2rem)] sm:h-[calc(100dvh-3rem)] lg:h-[calc(100dvh-4rem)] w-full lg:w-[360px] border-r bg-card/45 backdrop-blur-xl">
      <div className="p-4 sm:p-5 border-b">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="font-display text-lg">Your doubts</div>
            <div className="text-xs text-muted-foreground">
              Pick a thread or start a new one.
            </div>
          </div>
          <GradientButton
            onClick={() => setCreateOpen(true)}
            className="px-3 py-2"
            icon={<Plus className="h-4 w-4" />}
            data-testid="sidebar-newdoubt"
          >
            <span className="hidden sm:inline">New</span>
          </GradientButton>
        </div>

        <div className="mt-3 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search..."
            className="pl-9 h-11 rounded-2xl bg-card/60"
            data-testid="sidebar-search"
          />
        </div>
      </div>

      <div className="p-2 sm:p-3 overflow-auto no-scrollbar h-[calc(100%-108px)]">
        {list.isLoading ? (
          <div className="p-3 text-sm text-muted-foreground animate-pulse" data-testid="sidebar-loading">
            Loading conversations…
          </div>
        ) : list.isError ? (
          <div className="p-3 text-sm text-destructive" data-testid="sidebar-error">
            {(list.error as Error)?.message || "Failed to load conversations"}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-4">
            <div className="rounded-3xl border bg-card/60 p-4 shadow-[var(--shadow-sm)]">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-2xl border bg-gradient-to-br from-primary/15 to-accent/15 grid place-items-center">
                  <MessageSquareText className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-semibold">No conversations yet</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Create one and ask like you would a real tutor.
                  </div>
                </div>
              </div>
              <GradientButton
                onClick={() => setCreateOpen(true)}
                className="mt-4 w-full"
                icon={<Plus className="h-4 w-4" />}
                data-testid="sidebar-empty-create"
              >
                Start a new doubt
              </GradientButton>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((c) => {
              const active = c.id === activeId;
              const createdAt = asDate(c.createdAt);
              return (
                <div
                  key={c.id}
                  className={cn(
                    "group relative rounded-3xl border p-3 sm:p-3.5 bg-card/55 shadow-[var(--shadow-sm)]",
                    "hover:shadow-[var(--shadow)] hover:-translate-y-0.5 transition-all duration-300",
                    active && "ring-4 ring-primary/10 border-primary/35 bg-gradient-to-br from-primary/10 to-transparent"
                  )}
                >
                  <Link
                    href={`/c/${c.id}`}
                    className="block outline-none"
                    data-testid={`sidebar-conversation-${c.id}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-semibold truncate">{c.title}</div>
                        <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                          <span className="inline-flex items-center gap-1 rounded-full border bg-muted/60 px-2 py-0.5 capitalize">
                            <span className="h-1.5 w-1.5 rounded-full bg-primary/80" />
                            {c.problemType}
                          </span>
                          <span className="inline-flex items-center gap-1">
                            <Calendar className="h-3.5 w-3.5" />
                            {formatDistanceToNow(createdAt, { addSuffix: true })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Link>

                  <button
                    type="button"
                    onClick={() => setConfirmId(c.id)}
                    className={cn(
                      "absolute right-2 top-2 inline-flex h-9 w-9 items-center justify-center rounded-2xl border",
                      "bg-card/70 opacity-0 group-hover:opacity-100 transition-all duration-300",
                      "hover:bg-destructive hover:text-destructive-foreground hover:border-destructive/40 hover:shadow-[0_18px_40px_hsl(var(--destructive)/0.25)]",
                      "focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-destructive/20"
                    )}
                    aria-label="Delete conversation"
                    data-testid={`sidebar-delete-${c.id}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <ConversationCreateDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={(id) => setLocation(`/c/${id}`)}
      />

      <ConfirmDialog
        open={confirmId != null}
        onOpenChange={(o) => setConfirmId(o ? confirmId : null)}
        title="Delete this conversation?"
        description="This will remove the full chat thread. You can’t undo it."
        confirmText={del.isPending ? "Deleting…" : "Delete"}
        onConfirm={() => confirmId != null && onDelete(confirmId)}
        confirmDisabled={del.isPending}
        destructive
        data-testid="delete-conversation"
      />
    </aside>
  );
}
