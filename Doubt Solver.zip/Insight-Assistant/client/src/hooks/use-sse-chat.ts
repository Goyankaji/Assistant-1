import { useCallback, useRef, useState } from "react";
import { api, buildUrl, sseEventSchema, type SseEvent } from "@shared/routes";
import type { CreateTextMessageRequest, CreateImageMessageRequest, CreateVoiceMessageRequest } from "@shared/schema";
import { useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { decodePCM16ToFloat32, createAudioPlaybackContext } from "../../replit_integrations/audio/audio-utils";

type StreamState = {
  status: "idle" | "sending" | "streaming" | "done" | "error";
  userTranscript?: string;
  assistantTranscript: string;
  lastEvent?: SseEvent;
  error?: string;
  speaking: boolean;
};

function parseEvent(lineJson: unknown): SseEvent {
  const r = sseEventSchema.safeParse(lineJson);
  if (!r.success) {
    console.error("[Zod] sseEvent validation failed:", r.error.format(), lineJson);
    throw r.error;
  }
  return r.data;
}

async function readSse(
  res: Response,
  onEvent: (evt: SseEvent) => void
): Promise<void> {
  const reader = res.body?.getReader();
  if (!reader) throw new Error("No response body (SSE) present");

  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const raw of lines) {
      const line = raw.trimEnd();
      if (!line.startsWith("data: ")) continue;
      const payload = line.slice(6);
      if (!payload) continue;

      try {
        const json = JSON.parse(payload);
        const evt = parseEvent(json);
        onEvent(evt);
      } catch (e) {
        // tolerate partial lines / keep going
        if (!(e instanceof SyntaxError)) {
          console.error("[SSE] parse error:", e);
        }
      }
    }
  }
}

export function useSseChat(conversationId: number) {
  const qc = useQueryClient();
  const [state, setState] = useState<StreamState>({
    status: "idle",
    assistantTranscript: "",
    speaking: false,
  });

  const audioRef = useRef<{
    ctx: AudioContext | null;
    worklet: AudioWorkletNode | null;
    ready: boolean;
  }>({ ctx: null, worklet: null, ready: false });

  const ensureAudio = useCallback(async () => {
    if (audioRef.current.ready) return;
    const { ctx, worklet } = await createAudioPlaybackContext("/audio-playback-worklet.js", 24000);
    worklet.port.onmessage = (e) => {
      if (e.data?.type === "ended") {
        setState((p) => ({ ...p, speaking: false }));
      }
    };
    audioRef.current = { ctx, worklet, ready: true };
  }, []);

  const reset = useCallback(() => {
    audioRef.current.worklet?.port.postMessage({ type: "clear" });
    setState({ status: "idle", assistantTranscript: "", speaking: false });
  }, []);

  const sendText = useCallback(
    async (body: CreateTextMessageRequest) => {
      reset();
      setState((p) => ({ ...p, status: "sending" }));

      const validated = api.conversations.messages.sendText.input.parse(body);
      const url = buildUrl(api.conversations.messages.sendText.path, { id: conversationId });

      const res = await fetch(url, {
        method: api.conversations.messages.sendText.method,
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const errJson = await res.json();
          const parsed = api.conversations.messages.sendText.responses[400].safeParse(errJson);
          if (parsed.success) throw new Error(parsed.data.message);
        }
        throw new Error("Failed to send message");
      }

      setState((p) => ({ ...p, status: "streaming" }));

      await readSse(res, (evt) => {
        setState((prev) => {
          const next: StreamState = { ...prev, lastEvent: evt };
          if (evt.type === "user_transcript" && evt.data) next.userTranscript = evt.data;
          if (evt.type === "transcript" && evt.data) next.assistantTranscript = (prev.assistantTranscript || "") + evt.data;
          if (evt.type === "error") {
            next.status = "error";
            next.error = evt.error || "Streaming error";
          }
          if (evt.type === "done") next.status = "done";
          return next;
        });
      });

      qc.invalidateQueries({ queryKey: [api.conversations.get.path, conversationId] });
      qc.invalidateQueries({ queryKey: [api.conversations.list.path] });
    },
    [conversationId, qc, reset]
  );

  const sendImage = useCallback(
    async (body: CreateImageMessageRequest) => {
      reset();
      setState((p) => ({ ...p, status: "sending" }));

      const validated = api.conversations.messages.sendImage.input.parse(body);
      const url = buildUrl(api.conversations.messages.sendImage.path, { id: conversationId });

      const res = await fetch(url, {
        method: api.conversations.messages.sendImage.method,
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const errJson = await res.json();
          const parsed = api.conversations.messages.sendImage.responses[400].safeParse(errJson);
          if (parsed.success) throw new Error(parsed.data.message);
        }
        throw new Error("Failed to send image");
      }

      setState((p) => ({ ...p, status: "streaming" }));

      await readSse(res, (evt) => {
        setState((prev) => {
          const next: StreamState = { ...prev, lastEvent: evt };
          if (evt.type === "user_transcript" && evt.data) next.userTranscript = evt.data;
          if (evt.type === "transcript" && evt.data) next.assistantTranscript = (prev.assistantTranscript || "") + evt.data;
          if (evt.type === "error") {
            next.status = "error";
            next.error = evt.error || "Streaming error";
          }
          if (evt.type === "done") next.status = "done";
          return next;
        });
      });

      qc.invalidateQueries({ queryKey: [api.conversations.get.path, conversationId] });
      qc.invalidateQueries({ queryKey: [api.conversations.list.path] });
    },
    [conversationId, qc, reset]
  );

  const sendVoice = useCallback(
    async (body: CreateVoiceMessageRequest) => {
      reset();
      setState((p) => ({ ...p, status: "sending" }));
      await ensureAudio();

      const validated = api.conversations.messages.sendVoice.input.parse(body);
      const url = buildUrl(api.conversations.messages.sendVoice.path, { id: conversationId });

      const res = await fetch(url, {
        method: api.conversations.messages.sendVoice.method,
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const errJson = await res.json();
          const parsed = api.conversations.messages.sendVoice.responses[400].safeParse(errJson);
          if (parsed.success) throw new Error(parsed.data.message);
        }
        throw new Error("Failed to send voice");
      }

      setState((p) => ({ ...p, status: "streaming" }));

      await readSse(res, (evt) => {
        setState((prev) => {
          const next: StreamState = { ...prev, lastEvent: evt };
          if (evt.type === "user_transcript" && evt.data) next.userTranscript = evt.data;
          if (evt.type === "transcript" && evt.data) next.assistantTranscript = (prev.assistantTranscript || "") + evt.data;
          if (evt.type === "audio" && evt.data) {
            const samples = decodePCM16ToFloat32(evt.data);
            audioRef.current.worklet?.port.postMessage({ type: "audio", samples });
            next.speaking = true;
          }
          if (evt.type === "error") {
            next.status = "error";
            next.error = evt.error || "Streaming error";
          }
          if (evt.type === "done") next.status = "done";
          return next;
        });
      });

      audioRef.current.worklet?.port.postMessage({ type: "streamComplete" });

      qc.invalidateQueries({ queryKey: [api.conversations.get.path, conversationId] });
      qc.invalidateQueries({ queryKey: [api.conversations.list.path] });
    },
    [conversationId, ensureAudio, qc, reset]
  );

  const stopAudio = useCallback(() => {
    audioRef.current.worklet?.port.postMessage({ type: "stop" });
    setState((p) => ({ ...p, speaking: false }));
  }, []);

  const stopAll = useCallback(() => {
    stopAudio();
    // SSE cancellation: no direct abort here; callers can use AbortController if needed later.
    setState((p) => ({ ...p, status: "idle" }));
  }, [stopAudio]);

  return { state, sendText, sendImage, sendVoice, reset, stopAudio, stopAll };
}
