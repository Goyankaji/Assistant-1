import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type ConversationListResponse, type ConversationWithMessagesResponse } from "@shared/routes";
import type { CreateConversationRequest } from "@shared/schema";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

export function useConversations(params?: { cursor?: number; limit?: number }) {
  return useQuery({
    queryKey: [api.conversations.list.path, params?.cursor ?? null, params?.limit ?? null],
    queryFn: async () => {
      const url = new URL(api.conversations.list.path, window.location.origin);
      if (params?.cursor) url.searchParams.set("cursor", String(params.cursor));
      if (params?.limit) url.searchParams.set("limit", String(params.limit));

      const res = await fetch(url.toString().replace(window.location.origin, ""), {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch conversations");
      const json = await res.json();
      const parsed = parseWithLogging(api.conversations.list.responses[200], json, "conversations.list");

      // Ensure dates are Dates? API allows string|date; keep as-is but normalize for UI downstream.
      return parsed as ConversationListResponse;
    },
  });
}

export function useConversation(id: number) {
  return useQuery({
    queryKey: [api.conversations.get.path, id],
    enabled: Number.isFinite(id) && id > 0,
    queryFn: async () => {
      const url = buildUrl(api.conversations.get.path, { id });
      const res = await fetch(url, { credentials: "include" });

      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch conversation");

      const json = await res.json();
      return parseWithLogging(api.conversations.get.responses[200], json, "conversations.get") as ConversationWithMessagesResponse;
    },
  });
}

export function useCreateConversation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateConversationRequest) => {
      const validated = api.conversations.create.input.parse(data);
      const res = await fetch(api.conversations.create.path, {
        method: api.conversations.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const errJson = await res.json();
          const parsed = parseWithLogging(api.conversations.create.responses[400], errJson, "conversations.create.400");
          throw new Error(parsed.message);
        }
        throw new Error("Failed to create conversation");
      }

      const json = await res.json();
      return parseWithLogging(api.conversations.create.responses[201], json, "conversations.create.201");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.conversations.list.path] });
    },
  });
}

export function useDeleteConversation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.conversations.delete.path, { id });
      const res = await fetch(url, {
        method: api.conversations.delete.method,
        credentials: "include",
      });

      if (res.status === 404) {
        const errJson = await res.json();
        const parsed = parseWithLogging(api.conversations.delete.responses[404], errJson, "conversations.delete.404");
        throw new Error(parsed.message);
      }
      if (!res.ok) throw new Error("Failed to delete conversation");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [api.conversations.list.path] });
    },
  });
}
