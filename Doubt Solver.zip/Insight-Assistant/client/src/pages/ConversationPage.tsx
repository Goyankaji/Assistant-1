import AppShell from "@/components/AppShell";
import BrandHeader from "@/components/BrandHeader";
import ConversationSidebar from "@/components/ConversationSidebar";
import ChatMessageBubble from "@/components/ChatMessageBubble";
import ChatComposer from "@/components/ChatComposer";
import { SoftCard } from "@/components/SoftCard";
import { useConversation } from "@/hooks/use-conversations";
import { useSseChat } from "@/hooks/use-sse-chat";
import { useMemo, useRef, useEffect } from "react";
import { useRoute } from "wouter";
import { Bot, FileX2 } from "lucide-react";
import { format } from "date-fns";

function asDate(d: unknown): Date {
  if (d instanceof Date) return d;
  if (typeof d === "string") return new Date(d);
  return new Date();
}

export default function ConversationPage() {
  const [, params] = useRoute<{ id: string }>("/c/:id");
  const id = Number(params?.id);
  const convo = useConversation(id);
  const chat = useSseChat(id);

  const scrollRef = useRef<HTMLDivElement | null>(null);

  const messages = convo.data?.messages ?? [];
  const streamAssistantBubble = useMemo(() => {
    const text = chat.state.assistantTranscript?.trim() ?? "";
    if (!text) return null;
    // Show streaming assistant response as a live bubble (not persisted yet)
    return { role: "assistant", content: text, id: "stream" as const };
  }, [chat.state.assistantTranscript]);

  const merged = useMemo(() => {
    const base = messages.map((m) => ({ ...m, key: String(m.id) }));
    if (streamAssistantBubble) {
      base.push({
        id: -1,
        conversationId: id,
        role: "assistant",
        content: streamAssistantBubble.content,
        imageBase64: null,
        createdAt: new Date().toISOString(),
        key: "stream",
      });
    }
    return base;
  }, [messages, streamAssistantBubble, id]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [merged.length, chat.state.assistantTranscript]);

  const thinking = chat.state.status === "sending" || chat.state.status === "streaming";
  const speaking = chat.state.speaking;

  return (
    <AppShell>
      <div className="h-full">
        <BrandHeader />

        <div className="grid grid-cols-1 lg:grid-cols-[360px_1fr]">
          <ConversationSidebar />

          <main className="min-w-0 flex flex-col h-[calc(100dvh-120px)] lg:h-[calc(100dvh-96px)]">
            <div className="px-4 sm:px-6 pt-4 sm:pt-6">
              <SoftCard className="p-4 sm:p-5">
                {convo.isLoading ? (
                  <div className="animate-pulse" data-testid="conversation-loading">
                    <div className="h-4 w-28 bg-muted rounded" />
                    <div className="mt-3 h-7 w-2/3 bg-muted rounded" />
                  </div>
                ) : convo.isError ? (
                  <div className="text-destructive text-sm" data-testid="conversation-error">
                    {(convo.error as Error)?.message || "Failed to load conversation"}
                  </div>
                ) : !convo.data ? (
                  <div className="flex items-start gap-3" data-testid="conversation-notfound">
                    <div className="h-10 w-10 rounded-2xl border bg-card/60 grid place-items-center">
                      <FileX2 className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <div className="font-semibold">Conversation not found</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        It may have been deleted.
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="text-xs text-muted-foreground" data-testid="conversation-meta">
                        <span className="inline-flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full bg-primary/80" />
                          <span className="capitalize">{convo.data.problemType}</span>
                          <span className="text-muted-foreground/60">•</span>
                          <span>{format(asDate(convo.data.createdAt), "PP p")}</span>
                        </span>
                      </div>
                      <h1 className="mt-1 text-2xl sm:text-3xl leading-tight" data-testid="conversation-title">
                        {convo.data.title}
                      </h1>
                      <div className="mt-2 text-xs text-muted-foreground">
                        Expect clarifying questions — like a real tutor.
                      </div>
                    </div>

                    <div className="hidden md:flex items-center gap-2">
                      <div className="rounded-2xl border bg-gradient-to-br from-primary/12 to-accent/12 px-3 py-2 shadow-[var(--shadow-sm)]">
                        <div className="flex items-center gap-2 text-xs">
                          <Bot className="h-4 w-4 text-primary" />
                          <span className="font-semibold">Tutor</span>
                          <span className="text-muted-foreground/70">
                            {thinking ? "thinking" : speaking ? "speaking" : "ready"}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </SoftCard>
            </div>

            <div
              ref={scrollRef}
              className="flex-1 overflow-auto no-scrollbar px-4 sm:px-6 py-4 sm:py-6"
              data-testid="chat-scroll"
            >
              <div className="mx-auto max-w-3xl space-y-4 sm:space-y-5">
                {convo.data && messages.length === 0 ? (
                  <div className="rounded-3xl border bg-card/60 p-5 shadow-[var(--shadow-sm)] animate-rise" data-testid="chat-empty">
                    <div className="flex items-start gap-3">
                      <div className="h-11 w-11 rounded-3xl border bg-gradient-to-br from-primary/15 to-accent/15 grid place-items-center">
                        <Bot className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold">Start with your doubt</div>
                        <div className="mt-1 text-sm text-muted-foreground">
                          Try: “I keep mixing up oxidation states — can you quiz me?”
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}

                {merged.map((m) => (
                  <ChatMessageBubble
                    key={(m as any).key ?? String(m.id)}
                    role={m.role}
                    content={m.content}
                    imageBase64={m.imageBase64 ?? null}
                    createdAtLabel={m.id > 0 ? format(asDate(m.createdAt), "p") : "typing…"}
                  />
                ))}
              </div>
            </div>

            <ChatComposer
              disabled={!convo.data || thinking}
              thinking={thinking}
              speaking={speaking}
              onStopAudio={chat.stopAudio}
              problemTypeLabel={convo.data?.problemType}
              onSendText={(t) => chat.sendText({ content: t })}
              onSendImageBase64={(imageBase64, prompt) =>
                chat.sendImage({ imageBase64, prompt })
              }
              onSendVoiceBase64={(audio) =>
                chat.sendVoice({ audio, voice: "alloy" })
              }
            />
          </main>
        </div>
      </div>
    </AppShell>
  );
}
