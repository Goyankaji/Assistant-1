
import { useState } from "react";
import ProblemTypeFilter from "../components/ProblemTypeFilter";

export default function Home() {
  const [type, setType] = useState("DSA");

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <h1 className="text-3xl font-bold mb-2">Insight Assistant</h1>
      <p className="text-gray-600 mb-6">
        Choose problem type to explore interview questions
      </p>

      <ProblemTypeFilter onSelect={setType} />

      <div className="bg-white rounded-2xl shadow p-6">
        <h2 className="text-xl font-semibold mb-2">{type} Problems</h2>
        <p className="text-gray-500">
          Problems related to {type} will appear here.
        </p>
      </div>
    </div>
  );
}
