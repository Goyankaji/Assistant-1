import AppShell from "@/components/AppShell";
import BrandHeader from "@/components/BrandHeader";
import { SoftCard } from "@/components/SoftCard";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Camera, Mic, Palette, Shield } from "lucide-react";

export default function Settings() {
  return (
    <AppShell>
      <BrandHeader />

      <div className="p-4 sm:p-6 lg:p-10 animate-in-soft">
        <div className="mx-auto max-w-3xl">
          <div className="flex items-end justify-between gap-3">
            <div>
              <h1 className="text-3xl sm:text-4xl">Preferences</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Quick checks to keep the voice + camera experience smooth.
              </p>
            </div>
            <Link
              href="/"
              className="text-sm font-semibold text-primary hover:underline"
              data-testid="settings-back"
            >
              Back
            </Link>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-4">
            <SoftCard className="p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <div className="h-11 w-11 rounded-3xl border bg-gradient-to-br from-primary/15 to-accent/15 grid place-items-center">
                  <Mic className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <div className="font-semibold">Microphone</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Voice messages require mic permission. If it fails, check your browser site settings.
                  </div>
                  <Button
                    variant="outline"
                    className="mt-4 rounded-2xl"
                    onClick={async () => {
                      await navigator.mediaDevices.getUserMedia({ audio: true });
                    }}
                    data-testid="settings-test-mic"
                  >
                    Test microphone permission
                  </Button>
                </div>
              </div>
            </SoftCard>

            <SoftCard className="p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <div className="h-11 w-11 rounded-3xl border bg-gradient-to-br from-primary/15 to-accent/15 grid place-items-center">
                  <Camera className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <div className="font-semibold">Camera</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    For handwritten doubts, camera capture is fastest. Upload is always available as a fallback.
                  </div>
                  <Button
                    variant="outline"
                    className="mt-4 rounded-2xl"
                    onClick={async () => {
                      await navigator.mediaDevices.getUserMedia({ video: true });
                    }}
                    data-testid="settings-test-camera"
                  >
                    Test camera permission
                  </Button>
                </div>
              </div>
            </SoftCard>

            <SoftCard className="p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <div className="h-11 w-11 rounded-3xl border bg-gradient-to-br from-primary/15 to-accent/15 grid place-items-center">
                  <Palette className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <div className="font-semibold">Theme</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Use the sun/moon button in the header to toggle light/dark. It’s saved in your browser.
                  </div>
                </div>
              </div>
            </SoftCard>

            <SoftCard className="p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <div className="h-11 w-11 rounded-3xl border bg-gradient-to-br from-primary/15 to-accent/15 grid place-items-center">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <div className="font-semibold">Privacy note</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Images/voice are sent to the server for tutor responses. Don’t share sensitive info.
                  </div>
                </div>
              </div>
            </SoftCard>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
