import { sql } from "drizzle-orm";
import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const problemTypes = [
  "math",
  "physics",
  "chemistry",
  "biology",
  "coding",
  "english",
  "history",
  "other",
] as const;
export type ProblemType = (typeof problemTypes)[number];

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  problemType: text("problem_type").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id")
    .notNull()
    .references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(),
  content: text("content").notNull(),
  imageBase64: text("image_base64"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const createConversationBodySchema = insertConversationSchema.extend({
  problemType: z.enum(problemTypes),
});

export const createTextMessageBodySchema = z.object({
  content: z.string().min(1),
});

export const createImageMessageBodySchema = z.object({
  imageBase64: z.string().min(1),
  prompt: z.string().min(1).optional(),
});

export const createVoiceMessageBodySchema = z.object({
  audio: z.string().min(1),
  voice: z.enum(["alloy", "echo", "fable", "onyx", "nova", "shimmer"]).optional(),
});

export const humanTutorSystemPromptSchema = z.object({
  problemType: z.enum(problemTypes),
  style: z.enum(["friendly", "strict", "exam", "quick"]).default("friendly"),
  gradeLevel: z.enum(["middle", "high", "college"]).default("high"),
});

export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type CreateConversationRequest = z.infer<typeof createConversationBodySchema>;
export type CreateTextMessageRequest = z.infer<typeof createTextMessageBodySchema>;
export type CreateImageMessageRequest = z.infer<typeof createImageMessageBodySchema>;
export type CreateVoiceMessageRequest = z.infer<typeof createVoiceMessageBodySchema>;

export type ConversationResponse = Conversation;
export type MessageResponse = Message;
export type ConversationWithMessagesResponse = Conversation & { messages: Message[] };

export interface PaginatedResponse<T> {
  items: T[];
  nextCursor?: number;
}
