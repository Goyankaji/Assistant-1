import { z } from "zod";
import {
  createConversationBodySchema,
  createTextMessageBodySchema,
  createImageMessageBodySchema,
  createVoiceMessageBodySchema,
  problemTypes,
} from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const sseEventSchema = z.object({
  type: z.enum(["user_transcript", "transcript", "audio", "done", "error"]),
  data: z.string().optional(),
  transcript: z.string().optional(),
  error: z.string().optional(),
});

export const api = {
  meta: {
    problemTypes: {
      method: "GET" as const,
      path: "/api/meta/problem-types",
      responses: {
        200: z.object({
          items: z.array(z.enum(problemTypes)),
        }),
      },
    },
  },
  conversations: {
    list: {
      method: "GET" as const,
      path: "/api/conversations",
      input: z
        .object({
          cursor: z.coerce.number().int().positive().optional(),
          limit: z.coerce.number().int().min(1).max(50).optional(),
        })
        .optional(),
      responses: {
        200: z.array(
          z.object({
            id: z.number(),
            title: z.string(),
            problemType: z.string(),
            createdAt: z.string().or(z.date()),
          })
        ),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/conversations/:id",
      responses: {
        200: z.object({
          id: z.number(),
          title: z.string(),
          problemType: z.string(),
          createdAt: z.string().or(z.date()),
          messages: z.array(
            z.object({
              id: z.number(),
              conversationId: z.number(),
              role: z.string(),
              content: z.string(),
              imageBase64: z.string().nullable().optional(),
              createdAt: z.string().or(z.date()),
            })
          ),
        }),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/conversations",
      input: createConversationBodySchema,
      responses: {
        201: z.object({
          id: z.number(),
          title: z.string(),
          problemType: z.string(),
          createdAt: z.string().or(z.date()),
        }),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/conversations/:id",
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    messages: {
      sendText: {
        method: "POST" as const,
        path: "/api/conversations/:id/messages/text",
        input: createTextMessageBodySchema,
        responses: {
          200: sseEventSchema,
          400: errorSchemas.validation,
          404: errorSchemas.notFound,
        },
      },
      sendImage: {
        method: "POST" as const,
        path: "/api/conversations/:id/messages/image",
        input: createImageMessageBodySchema,
        responses: {
          200: sseEventSchema,
          400: errorSchemas.validation,
          404: errorSchemas.notFound,
        },
      },
      sendVoice: {
        method: "POST" as const,
        path: "/api/conversations/:id/messages/voice",
        input: createVoiceMessageBodySchema,
        responses: {
          200: sseEventSchema,
          400: errorSchemas.validation,
          404: errorSchemas.notFound,
        },
      },
    },
  },
};

export function buildUrl(
  path: string,
  params?: Record<string, string | number>
): string {
  let url = path;
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      url = url.replace(`:${key}`, String(value));
    }
  }
  return url;
}

export type ProblemTypesResponse = z.infer<typeof api.meta.problemTypes.responses[200]>;
export type ConversationListResponse = z.infer<typeof api.conversations.list.responses[200]>;
export type ConversationResponse = z.infer<typeof api.conversations.create.responses[201]>;
export type ConversationWithMessagesResponse = z.infer<typeof api.conversations.get.responses[200]>;
export type SseEvent = z.infer<typeof sseEventSchema>;
